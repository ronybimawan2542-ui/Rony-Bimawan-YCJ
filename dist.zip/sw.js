/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "screenshot-wide.png",
    "revision": "3c4f589a7125afb5e1d7f9e98768b2bf"
  }, {
    "url": "screenshot-mobile.png",
    "revision": "f5fcf2c429f35c38f65d80dac33f692f"
  }, {
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "683b2a940678315f8669ca968077b748"
  }, {
    "url": "pwa-96x96.png",
    "revision": "478e6a3c832d1c87075b4d54f515b25d"
  }, {
    "url": "pwa-512x512.png",
    "revision": "683b2a940678315f8669ca968077b748"
  }, {
    "url": "pwa-384x384.png",
    "revision": "88b094029acb3080701f2d4076a329d0"
  }, {
    "url": "pwa-256x256.png",
    "revision": "1b214505b7f5e9e94275a36f31472f22"
  }, {
    "url": "pwa-192x192.png",
    "revision": "08b0b7c0825c2fcf59f5096ffcc9c960"
  }, {
    "url": "pwa-128x128.png",
    "revision": "10241f93d0f1ca9fa503bd91fcc9a051"
  }, {
    "url": "index.html",
    "revision": "7364321c9f19db1efe151702cca4f751"
  }, {
    "url": "icon.svg",
    "revision": "38f296b49025d3eeadf1693ea3cea122"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b016de1cd7cffc93ae5821cb063e3fd5"
  }, {
    "url": "assets/index-CyDidZGe.css",
    "revision": null
  }, {
    "url": "assets/index-4PTxjraX.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "b016de1cd7cffc93ae5821cb063e3fd5"
  }, {
    "url": "icon.svg",
    "revision": "38f296b49025d3eeadf1693ea3cea122"
  }, {
    "url": "pwa-128x128.png",
    "revision": "10241f93d0f1ca9fa503bd91fcc9a051"
  }, {
    "url": "pwa-192x192.png",
    "revision": "08b0b7c0825c2fcf59f5096ffcc9c960"
  }, {
    "url": "pwa-256x256.png",
    "revision": "1b214505b7f5e9e94275a36f31472f22"
  }, {
    "url": "pwa-384x384.png",
    "revision": "88b094029acb3080701f2d4076a329d0"
  }, {
    "url": "pwa-512x512.png",
    "revision": "683b2a940678315f8669ca968077b748"
  }, {
    "url": "pwa-96x96.png",
    "revision": "478e6a3c832d1c87075b4d54f515b25d"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "683b2a940678315f8669ca968077b748"
  }, {
    "url": "manifest.webmanifest",
    "revision": "b89be8739c53ac67c81dfc7cac1e76f6"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
